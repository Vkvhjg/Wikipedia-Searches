let searchInputEl = document.getElementById("searchInput")
let searchResults = document.getElementById("searchResults")
let spinnerEl = document.getElementById("spinner")

function createAndAppendResults(result) {
    let {
        title,
        link,
        description
    } = result

    let resultItemEl = document.createElement("div")
    resultItemEl.classList.add("result-item")
    searchResults.appendChild(resultItemEl)

    let titleEl = document.createElement("a")
    titleEl.classList.add("result-title")
    titleEl.textContent = title
    titleEl.href = link
    titleEl.target = "_blank"
    resultItemEl.appendChild(titleEl)

    let breakEl = document.createElement("br")
    resultItemEl.appendChild(breakEl)

    let urlEl = document.createElement("a")
    urlEl.target = "_blank"
    urlEl.textContent = link
    urlEl.href = link
    urlEl.classList.add("result-url")
    resultItemEl.appendChild(urlEl)

    let breaEl = document.createElement("br")
    resultItemEl.appendChild(breaEl)

    let descriptionEl = document.createElement("p")
    descriptionEl.classList.add("link-description")
    descriptionEl.textContent = description
    resultItemEl.appendChild(descriptionEl)
}

function displayResults(searchResults) {
    spinnerEl.classList.toggle("d-none")
    for (let result of searchResults)
        createAndAppendResults(result)
}

function searchWikipedia() {
    if (event.key === "Enter") {
        searchResults.textContent = ""
        spinnerEl.classList.toggle("d-none")
        let searchInput = searchInputEl.value
        let url = "https://apis.ccbp.in/wiki-search?search=" + searchInput
        let option = {
            method: "GET"
        }
        fetch(url, option)
            .then(function(response) {
                return response.json()
            })
            .then(function(jsonData) {
                let {
                    search_results
                } = jsonData
                displayResults(search_results)


            })
    }

}



searchInputEl.addEventListener("keydown", searchWikipedia)